// backend/routes/adminRoutes.js
const express = require('express');
const router = express.Router();
const { createWorker, getWorkers } = require('../controllers/adminController');
const { protect } = require('../middleware/authMiddleware');

// Only admin users can access these routes
router.post('/create-worker', protect, async (req, res, next) => {
  if (req.user.role !== 'admin') {
    return res.status(403).json({ message: 'Access denied' });
  }
  next();
}, createWorker);

router.get('/workers', protect, async (req, res, next) => {
  if (req.user.role !== 'admin') {
    return res.status(403).json({ message: 'Access denied' });
  }
  next();
}, getWorkers);

module.exports = router;