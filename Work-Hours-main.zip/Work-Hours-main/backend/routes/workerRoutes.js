// backend/routes/workerRoutes.js
const express = require('express');
const router = express.Router();
const { addWorkEntry, getWorkEntries } = require('../controllers/workerController');
const { protect } = require('../middleware/authMiddleware');

router.post('/add-entry', protect, addWorkEntry);
router.get('/entries', protect, getWorkEntries);

module.exports = router;