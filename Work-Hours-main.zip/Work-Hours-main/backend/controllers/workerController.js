// backend/controllers/workerController.js
const WorkEntry = require('../models/WorkEntry');

exports.addWorkEntry = async (req, res) => {
  try {
    const { date, start, end } = req.body;
    // req.user is set by the auth middleware (worker's ID)
    const newEntry = new WorkEntry({
      worker: req.user.userId,
      date,
      start,
      end
    });
    await newEntry.save();
    res.status(201).json({ message: 'Work entry added', entry: newEntry });
  } catch (error) {
    res.status(500).json({ message: 'Server error', error: error.message });
  }
};

exports.getWorkEntries = async (req, res) => {
  try {
    let query = {};
    // If the logged-in user is a worker, only return their entries
    if (req.user.role === 'worker') {
      query.worker = req.user.userId;
    }
    // Admins may retrieve all work entries
    const entries = await WorkEntry.find(query).populate('worker', 'name email');
    res.json(entries);
  } catch (error) {
    res.status(500).json({ message: 'Server error', error: error.message });
  }
};