// backend/controllers/adminController.js
const User = require('../models/User');
const bcrypt = require('bcrypt');

// Create a new worker account
exports.createWorker = async (req, res) => {
  try {
    const { name, email, password } = req.body;
    // Check if the worker already exists
    const existingUser = await User.findOne({ email });
    if (existingUser) {
      return res.status(400).json({ message: 'Worker already exists' });
    }
    // Hash the password before saving
    const hashedPassword = await bcrypt.hash(password, 10);
    const newWorker = new User({
      name,
      email,
      password: hashedPassword,
      role: 'worker'
    });
    await newWorker.save();
    res.status(201).json({ message: 'Worker created successfully', worker: newWorker });
  } catch (error) {
    res.status(500).json({ message: 'Server error', error: error.message });
  }
};

// Get all workers (only accessible by admin)
exports.getWorkers = async (req, res) => {
  try {
    const workers = await User.find({ role: 'worker' }).select('-password');
    res.json(workers);
  } catch (error) {
    res.status(500).json({ message: 'Server error', error: error.message });
  }
};