// backend/models/WorkEntry.js
const mongoose = require('mongoose');

const WorkEntrySchema = new mongoose.Schema(
  {
    worker: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
    date: { type: Date, required: true },
    start: { type: String, required: true },
    end: { type: String, required: true }
  },
  { timestamps: true }
);

module.exports = mongoose.model('WorkEntry', WorkEntrySchema);