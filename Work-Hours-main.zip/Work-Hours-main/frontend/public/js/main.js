// frontend/public/js/main.js

document.addEventListener("DOMContentLoaded", () => {
  // Handle login form submission
  const loginForm = document.getElementById("loginForm");
  if (loginForm) {
    loginForm.addEventListener("submit", async (e) => {
      e.preventDefault();
      const email = document.getElementById("email").value;
      const password = document.getElementById("password").value;
      try {
        const res = await fetch("/api/auth/login", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ email, password })
        });
        const data = await res.json();
        if (res.ok) {
          // Store token for future requests
          localStorage.setItem("token", data.token);
          // Redirect to the dashboard page
          window.location.href = "dashboard.html";
        } else {
          alert(data.message);
        }
      } catch (error) {
        console.error("Error logging in:", error);
      }
    });
  }

  // Additional client-side logic (if any) can be added here.
});