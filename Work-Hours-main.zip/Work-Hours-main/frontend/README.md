# My Work Platform

A full-stack platform where workers log in, submit their work hours, and admins manage worker accounts.

## Features
- **Worker Login:** Secure login using JWT authentication.
- **Worker Dashboard:** Submit and view work entries.
- **Admin Panel:** Create worker accounts and view workers.
- **Modern & Responsive Design:** Built with Bootstrap and custom CSS.
- **Backend:** Node.js, Express, and MongoDB (via Mongoose).
- **Authentication:** JWT-based authentication with password hashing.

## Setup
1. Clone the repository.
2. Run `npm install` in the project root.
3. Create a `.env` file (see sample above).
4. Run `npm run dev` for development or `npm start` for production.
5. Open [http://localhost:5000](http://localhost:5000) to access the app.

## File Structure